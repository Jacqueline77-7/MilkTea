/* ============================================================
 *  心情奶茶推荐 · 交互逻辑（日系治愈茶室版 · Q版猫咪抱奶茶）
 *  - Q版猫咪抱珍珠奶茶图片角色（呼吸动画）
 *  - 测试流程 / 标签权重匹配推荐（引擎保持不变）
 *  - 结果页：沉浸式叙事 + 情绪人格，弱化商品感
 *  - 分享"我的今日人格"
 * ============================================================ */
(function () {
  'use strict';

  const state = {
    step: 0,
    answers: [],
    userTags: {},
    prefs: { temperature: '随机', type: '随机', brand: '其他随机品牌' },
    result: [],
    note: null,
    special: null,
    triggerGift: false,
    day: 1,
  };

  /* 宠物图片路径（透明 PNG 贴纸：Q版猫咪抱奶茶主体） */
  const PET_IMG = 'assets/cat-tea-pet.png';

  const $ = (id) => document.getElementById(id);
  const showScreen = (id) => {
    document.querySelectorAll('.screen').forEach((s) => s.classList.remove('active'));
    $(id).classList.add('active');
  };
  const stripEmoji = (s) =>
    s.replace(/^[\s]*[\u{1F000}-\u{1FAFF}\u{2600}-\u{27BF}\u{2190}-\u{21FF}\u{2B00}-\u{2BFF}\u{FE0F}]+\s*/u, '');

  /* ---------------- 手绘插画（礼物/蛋糕保留 SVG） ---------------- */
  function giftSVG() {
    return `
    <svg viewBox="0 0 140 140" xmlns="http://www.w3.org/2000/svg">
      <ellipse cx="70" cy="124" rx="46" ry="8" fill="#d9c7a8" opacity=".5"/>
      <rect x="30" y="58" width="80" height="64" rx="12" fill="#cdb79a"/>
      <rect x="30" y="58" width="80" height="22" rx="8" fill="#b08968"/>
      <rect x="62" y="30" width="16" height="92" rx="6" fill="#efe3cf"/>
      <path d="M70 30 Q42 12 38 34 Q58 40 70 30 Z" fill="#efe3cf"/>
      <path d="M70 30 Q98 12 102 34 Q82 40 70 30 Z" fill="#efe3cf"/>
      <circle cx="70" cy="30" r="6.5" fill="#b08968"/>
    </svg>`;
  }

  function cakeSVG() {
    return `
    <svg viewBox="0 0 140 140" xmlns="http://www.w3.org/2000/svg">
      <ellipse cx="70" cy="122" rx="44" ry="8" fill="#d9c7a8" opacity=".5"/>
      <rect x="34" y="74" width="72" height="44" rx="12" fill="#efe3cf"/>
      <path d="M34 86 Q70 74 106 86 L106 96 Q70 84 34 96 Z" fill="#e7d3b8"/>
      <rect x="34" y="74" width="72" height="12" rx="6" fill="#fff7ea"/>
      <rect x="68" y="44" width="4" height="18" rx="2" fill="#efe3cf"/>
      <path d="M70 38 Q65 43 70 47 Q75 43 70 38 Z" fill="#e0a458"/>
      <circle cx="70" cy="70" r="6" fill="#b08968"/>
      <rect x="68" y="56" width="4" height="16" rx="2" fill="#9aa17a"/>
      <circle cx="60" cy="104" r="2.6" fill="#9b8366"/>
      <circle cx="80" cy="104" r="2.6" fill="#9b8366"/>
      <path d="M62 112 Q70 118 78 112" stroke="#9b8366" stroke-width="2" fill="none" stroke-linecap="round"/>
    </svg>`;
  }

  /* ---------------- 推荐引擎（三级逻辑：硬筛选 → 降级 → 权重） ---------------- */
  function drinkHasTag(d, tag) {
    if (d.tags.includes(tag)) return true;
    const syn = TAG_SYNONYMS[tag];
    return !!(syn && syn.some((s) => d.tags.includes(s)));
  }

  // 全部品牌（用于「随机」品牌选择时开放全库匹配）
  const ALL_BRANDS = [...new Set(DRINKS.map((d) => d.brand))];

  // 解析品牌选择 → 候选品牌列表（随机 = 全部品牌）
  function resolveBrands(choice) {
    if (choice === '其他随机品牌' || choice === '随机') return ALL_BRANDS;
    return BRAND_POOL[choice] || [choice];
  }

  // 第三层：权重计算（情绪场景60% / 品类15% / 温度15% / 品牌10%）
  function scoreDrink(d, userTags, prefs) {
    let scene = 0, fullScene = 0;
    for (const t in userTags) {
      fullScene += userTags[t] * 2;
      if (drinkHasTag(d, t)) scene += userTags[t] * 2;
    }
    if (fullScene <= 0) fullScene = 1;
    const normScene = (scene / fullScene) * WEIGHTS.scene * 100;
    const typeOk = prefs.type === '随机' || d.type === prefs.type;
    const tempOk = prefs.temperature === '随机' || d.temperature === prefs.temperature;
    const brandOk = prefs.brand === '其他随机品牌' || d.brand === prefs.brand;
    const total = normScene
      + (typeOk ? WEIGHTS.type * 100 : 0)
      + (tempOk ? WEIGHTS.temp * 100 : 0)
      + (brandOk ? WEIGHTS.brand * 100 : 0);
    return Math.round(total * 10) / 10;
  }

  function rankDrinks(list, userTags, prefs) {
    const scored = list.map((d) => ({ drink: d, total: scoreDrink(d, userTags, prefs) }));
    scored.sort((a, b) => b.total - a.total);
    return scored;
  }

  /* 三级推荐主逻辑
   * 返回 { ranked: [{drink,total}], note: string|null, special: {title,tip}|null }
   * - note:    降级提示（如温度不匹配）——不弹错误页，只做温柔提醒
   * - special: 品牌无对应系列时的特殊结果卡
   */
  function recommend(userTags, prefs) {
    const candBrands = resolveBrands(prefs.brand);
    const inBrands = DRINKS.filter((d) => candBrands.includes(d.brand));
    const wantType = prefs.type;
    const wantTemp = prefs.temperature;
    const isRandomBrand = prefs.brand === '其他随机品牌';

    // ---- 第一层：硬性条件过滤（品牌已限定，再按品类+温度筛选） ----
    const exact = inBrands.filter((d) =>
      (wantType === '随机' || d.type === wantType) &&
      (wantTemp === '随机' || d.temperature === wantTemp)
    );
    if (exact.length > 0) {
      return { ranked: rankDrinks(exact, userTags, prefs), note: null, special: null };
    }

    const typeExists = wantType === '随机' ? true : inBrands.some((d) => d.type === wantType);

    // ---- 第二层：降级策略（禁止随机推荐，按情况给明确提示/特殊卡） ----
    // 情况一：品牌+品类存在，但温度不匹配 → 忽略温度，推荐同品牌同品类
    if (wantType !== '随机' && wantTemp !== '随机') {
      if (typeExists) {
        const sameBrandType = inBrands.filter((d) => d.type === wantType);
        return {
          ranked: rankDrinks(sameBrandType, userTags, prefs),
          note: isRandomBrand
            ? '暂时没有完全符合温度的饮品哦，为你推荐最接近的选择'
            : '这个品牌暂时没有符合温度的饮品哦，为你推荐最接近的选择',
          special: null,
        };
      }
      // 情况二：品牌存在但品类不存在（如某品牌无咖啡系列）→ 特殊结果卡
      return {
        ranked: rankDrinks(inBrands, userTags, prefs), // 同品牌最符合心情
        note: null,
        special: {
          title: '这次的选择有一点小意外',
          tip: '偷偷告诉你：这个品牌目前没有该系列哦～不过你的心情已经被我们悄悄捕捉到了。',
        },
      };
    }

    // 仅温度指定（品类随机）但品牌内无该温度 → 忽略温度，推荐同品牌
    if (wantType === '随机' && wantTemp !== '随机') {
      return {
        ranked: rankDrinks(inBrands, userTags, prefs),
        note: isRandomBrand
          ? '暂时没有完全符合温度的饮品哦，为你推荐最接近的选择'
          : '这个品牌暂时没有符合温度的饮品哦，为你推荐最接近的选择',
        special: null,
      };
    }

    // 品类指定但温度随机，且品牌无该品类 → 特殊结果卡
    if (wantType !== '随机' && wantTemp === '随机' && !typeExists) {
      return {
        ranked: rankDrinks(inBrands, userTags, prefs),
        note: null,
        special: {
          title: '这次的选择有一点小意外',
          tip: '偷偷告诉你：这个品牌目前没有该系列哦～不过你的心情已经被我们悄悄捕捉到了。',
        },
      };
    }

    // 兜底：品类随机且温度随机 → 按心情排序（品牌随机时常见路径）
    return { ranked: rankDrinks(inBrands, userTags, prefs), note: null, special: null };
  }
  function negativeSum(userTags) {
    let s = 0;
    NEGATIVE_TAGS.forEach((t) => { if (userTags[t]) s += userTags[t]; });
    return s;
  }

  /* ---------------- 奶茶人格匹配 ---------------- */
  function matchScore(tagsMap, target) {
    let s = 0;
    for (const t in tagsMap) {
      if (target[t]) s += tagsMap[t] * target[t];
      else {
        const syn = TAG_SYNONYMS[t];
        if (syn) syn.forEach((sy) => { if (target[sy]) s += tagsMap[t] * target[sy] * 0.6; });
      }
    }
    return s;
  }
  function pickPersonality(userTags) {
    let best = PERSONALITIES[0], bestScore = -1;
    PERSONALITIES.forEach((p) => {
      const sc = matchScore(userTags, p.tags);
      if (sc > bestScore) { bestScore = sc; best = p; }
    });
    return best;
  }
  function topKeywords(userTags, n) {
    return Object.entries(userTags)
      .sort((a, b) => b[1] - a[1])
      .slice(0, n)
      .map(([t]) => TAG_FRIENDLY[t] || t);
  }

  /* ---------------- 测试流程 ---------------- */
  function renderQuestion(idx) {
    const q = QUESTIONS[idx];
    state.step = idx;
    $('progressText').textContent = `第 ${idx + 1} / ${QUESTIONS.length} 题`;
    $('progressFill').style.width = ((idx + 1) / QUESTIONS.length) * 100 + '%';

    // 题目标题前添加 emoji（data.js 中每题已有 emoji 字段）
    const emojiPrefix = q.emoji ? `<span class="q-emoji">${q.emoji}</span>` : '';
    const opts = q.options
      .map((o) => `<button class="q-option"><span class="q-key">${o.key}</span><span class="q-text">${stripEmoji(o.text)}</span></button>`)
      .join('');
    $('questionCard').innerHTML = `
      <h2 class="q-title">${emojiPrefix}${q.title}</h2>
      <div class="q-options">${opts}</div>`;

    const buttons = $('questionCard').querySelectorAll('.q-option');
    buttons.forEach((btn, i) => {
      btn.addEventListener('click', () => {
        buttons.forEach((b) => b.classList.remove('selected'));
        btn.classList.add('selected');
        chooseOption(q, q.options[i]);
      });
    });
  }

  function chooseOption(q, option) {
    state.answers[q.id] = option.key;
    if (q.type === 'scene') {
      for (const tag in option.tags) state.userTags[tag] = (state.userTags[tag] || 0) + option.tags[tag];
    } else {
      state.prefs[q.prefKey] = option.value;
    }
    setTimeout(() => {
      if (state.step + 1 < QUESTIONS.length) renderQuestion(state.step + 1);
      else finishTest();
    }, 340);
  }

  function finishTest() {
    showScreen('screen-loading');
    const rec = recommend(state.userTags, state.prefs);
    state.result = rec.ranked;
    state.note = rec.note;
    state.special = rec.special;
    state.triggerGift = negativeSum(state.userTags) >= NEGATIVE_THRESHOLD;
    setTimeout(() => {
      if (state.triggerGift) showScreen('screen-gift');
      else { renderResult(); showScreen('screen-result'); }
    }, 2300);
  }

  /* ---------------- 结果页（沉浸式叙事 + 人格） ---------------- */
  function renderResult() {
    const lucky = state.result[0].drink;
    const persona = pickPersonality(state.userTags);
    const keywords = topKeywords(state.userTags, 3);

    $('stateName').textContent = `${persona.emoji} ${persona.state}`;
    $('keywordText').textContent = keywords.join(' · ');

    // 特殊结果卡（品牌无对应系列）
    const specialCard = $('specialCard');
    if (state.special) {
      specialCard.style.display = 'block';
      $('specialTitle').textContent = state.special.title;
      $('specialTip').textContent = state.special.tip;
      $('luckyTeaHead').textContent = '根据你的状态，推荐这杯：';
    } else {
      specialCard.style.display = 'none';
      $('luckyTeaHead').textContent = '你的幸运茶';
    }

    // 降级提示（如品牌无对应温度）
    const recNote = $('recNote');
    if (state.note) { recNote.style.display = 'block'; recNote.textContent = state.note; }
    else recNote.style.display = 'none';

    $('luckyTeaName').textContent = lucky.name;
    $('luckyTeaLine').textContent = LUCKY_POEM[lucky.name] || '像一盏小灯，陪你慢慢结束今天。';

    $('personaEmoji').textContent = persona.emoji;
    $('personaName').textContent = persona.name;
    $('personaDesc').textContent = persona.desc;
    $('personaCard').classList.remove('show');

    $('adviceModule').innerHTML = buildAdvice();
    window.scrollTo({ top: 0 });
  }

  /* ---------------- 暖心建议（无 emoji，细节点缀） ---------------- */
  function buildAdvice() {
    const lucky = state.result[0].drink;
    const tags = state.userTags;
    const items = [];
    if (lucky.sweetness === '偏甜') items.push('这杯偏甜，下午喝刚刚好，晚上记得少糖少负担。');
    else if (lucky.sweetness === '低甜' || lucky.sweetness === '偏低甜') items.push('低糖清爽，正在控糖也能安心享用。');
    else items.push('中甜口味，甜度刚刚好，放心喝。');
    if (lucky.temperature === '热饮') items.push('热饮暖暖的，捧在手里就能治愈一整晚。');
    else items.push('冰冰凉凉超解压，记得别空腹贪凉。');
    if (negativeSum(tags) >= NEGATIVE_THRESHOLD) items.push('最近有点累，喝完这杯就早点休息，你比任务更重要。');
    if (tags['独处']) items.push('独处的时光也很珍贵，这杯茶就是专属你的小陪伴。');
    if (tags['社交']) items.push('今天有好好和朋友聊天，把这份开心也分一点给茶。');
    if (tags['压力']) items.push('压力大的时候，深呼吸三次，再给自己一个拥抱。');

    return `<div class="advice-head">给今天的你 · 小提醒</div>` +
      items.slice(0, 4).map((t) => `<div class="advice-item"><span class="advice-dot"></span><span>${t}</span></div>`).join('');
  }

  /* ---------------- 分享卡：我的今日人格（使用宠物图片） ---------------- */
  function buildShareCard() {
    const lucky = state.result[0].drink;
    const persona = pickPersonality(state.userTags);
    const keywords = topKeywords(state.userTags, 3);
    return `
      <span class="sc-deco" style="top:18px;left:20px">☾</span>
      <span class="sc-deco" style="top:20px;right:20px">✿</span>
      <div class="sc-top">— 我 的 今 日 人 格 —</div>
      <img class="sc-cat" src="${PET_IMG}" alt="今日茶室猫咪">
      <div class="sc-persona">${persona.emoji} ${persona.name}</div>
      <div class="sc-state">${persona.state}</div>
      <div class="sc-keywords">关键词 · ${keywords.join(' · ')}</div>
      <div class="sc-quote">${persona.desc}</div>
      <div class="sc-foot">今日茶室 · 慢慢来，你值得被好好对待</div>`;
  }

  /* ---------------- 陪伴宠物（Q版猫咪，保留点击交互） ---------------- */
  let petTimer = null;
  function petTalk() {
    const pet = $('pet');
    const speech = $('petSpeech');
    speech.textContent = ENCOURAGE_WORDS[Math.floor(Math.random() * ENCOURAGE_WORDS.length)];
    speech.classList.add('show');
    pet.classList.remove('wink');
    void pet.offsetWidth;
    pet.classList.add('wink');
    clearTimeout(petTimer);
    petTimer = setTimeout(() => speech.classList.remove('show'), 2600);
  }

  /* ---------------- 初始化 ---------------- */
  function init() {
    // 宠物图片已通过 HTML img 标签直接引用，无需 JS 注入 SVG
    // 仅需设置分享卡和礼物/蛋糕的 SVG
    $('giftBox').innerHTML = giftSVG();
    $('cakeIllu').innerHTML = cakeSVG();

    $('startBtn').addEventListener('click', () => {
      state.step = 0; state.answers = []; state.userTags = {};
      state.prefs = { temperature: '随机', type: '随机', brand: '其他随机品牌' };
      state.day = 1;
      $('pet').classList.add('show');
      renderQuestion(0);
      showScreen('screen-test');
    });

    $('openGiftBtn').addEventListener('click', () => {
      $('giftBox').classList.add('shake');
      $('openGiftBtn').style.display = 'none';
      setTimeout(() => {
        $('giftReveal').classList.add('show');
        $('giftBox').style.display = 'none';
      }, 700);
    });
    $('giftContinueBtn').addEventListener('click', () => {
      renderResult();
      showScreen('screen-result');
    });

    $('retakeBtn').addEventListener('click', () => {
      state.step = 0; state.answers = []; state.userTags = {};
      state.prefs = { temperature: '随机', type: '随机', brand: '其他随机品牌' };
      state.day = (state.day || 1) + 1;
      renderQuestion(0);
      showScreen('screen-test');
    });

    $('personaBtn').addEventListener('click', () => {
      $('personaCard').classList.toggle('show');
      $('personaBtn').textContent = $('personaCard').classList.contains('show')
        ? '收下奶茶人格 ↑' : '查看你的奶茶人格 →';
    });

    $('shareBtn').addEventListener('click', () => {
      $('shareCard').innerHTML = buildShareCard();
      $('shareOverlay').classList.add('show');
    });
    $('closeShareBtn').addEventListener('click', () => $('shareOverlay').classList.remove('show'));
    $('shareOverlay').addEventListener('click', (e) => {
      if (e.target === $('shareOverlay')) $('shareOverlay').classList.remove('show');
    });

    $('pet').addEventListener('click', petTalk);
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
